Title: Credit Card Approval System
Description: This is a simple credit card approval and monitoring system. allows the user to add a specific customer to the database, add a credit card/s to this customer or to other customers, control the debt and credit activities of a customers. also, credit card numbers are generated validly and is checked by the lhun-check algorithm to make sure of the validity of the cards generated. also allows an automatic save of database within every 5 minutes of the program runtime (just a pretty neat feature i added up in this program). program is by team baba, flores &amp; rapanot.. ;)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5272&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
